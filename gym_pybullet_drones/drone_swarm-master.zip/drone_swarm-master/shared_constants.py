AGGR_PHY_STEPS = 5
"""int: Aggregate PyBullet/physics steps within a single call to env.step()."""
