# Multi Drone Control Using Graph Neural Networks

## Requirements
This code was tested with Python 3.6 running on Ubuntu 18.04

The major dependencies are [gym-pybullet-drones](https://github.com/utiasDSL/gym-pybullet-drones), [SwarmNet](https://github.com/siyuzhou/SwarmNet) and [Swarms](https://github.com/siyuzhou/Swarms) (if you want to generate trajectories to train on)
